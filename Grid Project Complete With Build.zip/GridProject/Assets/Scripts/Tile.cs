using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Tile : MonoBehaviour
{
    [SerializeField] private SpriteRenderer spriteRenderer;
    private Color tileColor;
    private GameController gameController;
    private Vector2 position;

    
    public Vector2 Position { get => position; set => position = value; }

    private void Start()
    {
        tileColor = spriteRenderer.color;
    }

    private void OnMouseEnter()
    {
        tileColor = spriteRenderer.color;
        gameController.SetCurrentTile(this);
    }

    private void OnMouseExit()
    {        
        SetOnMouseExitColor();
        gameController.DeselectCurrentTile();
    }

    public void SetTileColor(Color color)
    {
        tileColor = color;
        spriteRenderer.color = color;
    }

    public void SetOnMouseEnterColor(Color color)
    {
        spriteRenderer.color = color;
    }

    public void SetOnMouseExitColor()
    {
        spriteRenderer.color = tileColor;
    }

    public void SetGameController(GameController gameControllerReference)
    {
        gameController = gameControllerReference;
    }

}
