using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameController : MonoBehaviour
{   

    [Header("Grid Creation")]
    [SerializeField] private float gridWidth;
    [SerializeField] private float gridHeight;
    [SerializeField] private GameObject tilePrefab;
    [SerializeField] private Transform tilesParent;

    [Header("Game Components")]

    [SerializeField] private Transform gameCamera;
    [SerializeField] private Brush gameBrush;
    [SerializeField] private Color defaultBrushColor;
    [SerializeField] private Eraser gameEraser;
    [SerializeField] private CursorIcon cursorIconScript;

    [Header("UI Components")]
    [SerializeField] private BrushUIPanelControl uiBrushPanel;

    private Dictionary<Vector2, Tile> spawnedTiles = new Dictionary<Vector2, Tile>();
    private List<Tool> gameTools = new List<Tool>();

    private Tool.ENUM_Tools activeTool;

    public Brush GameBrush { get => gameBrush; }
    public BrushUIPanelControl UiBrushPanel { get => uiBrushPanel; }

    private void Start()
    {
        gameTools.Add(GameBrush);
        gameTools.Add(gameEraser);

        SetCurrentTool(Tool.ENUM_Tools.BRUSH);
        UiBrushPanel.SetBrushCustomColor(defaultBrushColor);

        GenerateGrid();
    }

    //Generar grid del tama�o definido por width y height
    private void GenerateGrid()
    {
        for (int i = 0; i < gridWidth; i++)
        {
            for (int j = 0; j < gridHeight; j++)
            {
                GameObject newTile = Instantiate(tilePrefab, new Vector2(i, j), Quaternion.identity);
                newTile.name = "Tile " + i + "." + j;
                newTile.transform.parent = tilesParent;
                newTile.GetComponent<Tile>().SetGameController(this);
                newTile.GetComponent<Tile>().Position = new Vector2(i, j);

                spawnedTiles[new Vector2(i, j)] = newTile.GetComponent<Tile>();
            }
        }

        //Ubica la camara principal en el centro del grid
        gameCamera.position = new Vector3((gridWidth / 2) - 0.5f, (gridHeight / 2) - 0.5f, -10);
    }

    public Tile GetTileInPosition(Vector2 pos)
    {
        if (spawnedTiles.TryGetValue(pos, out var tile))
        {
            return tile;
        }

        return null;
    }

    public float GetCanvasHeight()
    {
        return gridHeight;
    }

    public float GetCanvasWidth()
    {
        return gridWidth;
    }

    public void SetCurrentTile(Tile currentTile)
    {
        switch (activeTool)
        {
            case Tool.ENUM_Tools.BRUSH:
                gameBrush.SetSelectedTile(currentTile);
                break;
            case Tool.ENUM_Tools.ERASER:
                gameEraser.HighlightSelectedTile(currentTile);
                break;
        }
    }

    public void DeselectCurrentTile()
    {
        switch (activeTool)
        {
            case Tool.ENUM_Tools.BRUSH:
                gameBrush.UnPaintSelectedTile();
                break;
            case Tool.ENUM_Tools.ERASER:
                gameEraser.DeselectCurrentTile();
                break;
        }
    }

    public void SetCurrentTool(Tool.ENUM_Tools tool)
    {
        activeTool = tool;

        for(int i = 0; i < gameTools.Count; i++)
        {
            if(gameTools[i].GetToolType() == tool)
            {
                gameTools[i].SetActiveTool(true);
                cursorIconScript.ChangeCursorSprite(gameTools[i].GetCursorIcon());
            }
            else
            {
                gameTools[i].SetActiveTool(false);
            }
        }
    }



}
