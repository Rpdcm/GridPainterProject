using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Eraser : Tool
{
    private Color eraserColor = Color.white;
    private Tile selectedTile;


    private void Update()
    {
        if (Input.GetMouseButton(0))
        {
            Erase();
        }
    }

    public void HighlightSelectedTile(Tile tile)
    {
        selectedTile = tile;
        //OnMouseEnterAdjacentTilesColor();
    }

    public void DeselectCurrentTile()
    {
        //OnMouseExitAdjacentTilesColor();
        selectedTile = null;
    }


    public void OnMouseEnterAdjacentTilesColor()
    {
        selectedTile.SetOnMouseEnterColor(eraserColor);
    }

    public void OnMouseExitAdjacentTilesColor()
    {
        selectedTile.SetOnMouseExitColor();
    }

    public void Erase()
    {
        if (selectedTile != null)
        {
            selectedTile.SetTileColor(eraserColor);
        }
    }
}
