using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CursorIcon : MonoBehaviour
{    
    [SerializeField] private SpriteRenderer spriteRenderer;

    private void Start()
    {
        Cursor.visible = false;       
    }

    // Update is called once per frame
    void Update()
    {
        Vector2 cursorPos = Camera.main.ScreenToWorldPoint(Input.mousePosition);
        transform.position = cursorPos;
    }

    public void ChangeCursorSprite(Sprite sprite)
    {
        spriteRenderer.sprite = sprite;
    }
}
