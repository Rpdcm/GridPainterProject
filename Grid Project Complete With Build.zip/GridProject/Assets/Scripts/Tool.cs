using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Tool : MonoBehaviour
{
    public enum ENUM_Tools
    {
        BRUSH,
        ERASER
    }

    [Header("In game Data")]
    [SerializeField] protected GameController gameController;
    [SerializeField] protected ENUM_Tools tool;
    protected bool isToolActive;

    [Header("UI")]
    [SerializeField] protected Sprite activeSprite;
    [SerializeField] protected Sprite unactiveSprite;
    [SerializeField] protected Image buttonImage;
    [SerializeField] protected Sprite cursorIcon;



    public virtual void SetActiveTool(bool status)
    {
        isToolActive = status;

        if (isToolActive)
        {
            buttonImage.sprite = activeSprite;
        }
        else
        {
            buttonImage.sprite = unactiveSprite;
        }
    }

    public void ToggleTool()
    {
        if (!isToolActive)
        {
            gameController.SetCurrentTool(tool);
        }
    }

    public ENUM_Tools GetToolType()
    {
        return tool;
    }

    public Sprite GetCursorIcon()
    {
        return cursorIcon;
    }
}
