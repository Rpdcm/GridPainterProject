using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class BrushUIPanelControl : MonoBehaviour
{
    [Header("Brush")]
    [SerializeField] private Brush brush;
    [Header("Color Selector")]
    [SerializeField] private Image selectedColorImage;
    [SerializeField] private TMP_Text rInput;
    [SerializeField] private TMP_Text gInput;
    [SerializeField] private TMP_Text bInput;
    [SerializeField] private Slider rSlider;
    [SerializeField] private Slider gSlider;
    [SerializeField] private Slider bSlider;
    [Header("Brush Size")]
    [SerializeField] private TMP_Text labelBrushSize;
    [SerializeField] private Slider brushSizeSlider;

    private const float RGB_MAX_VALUE = 255;
    private const float SIZE_MAX_VALUE = 5;
    private const string SIZE_LABEL_TEXT = "Brush Size: ";


    // Start is called before the first frame update
    void Start()
    {
        rSlider.onValueChanged.AddListener(delegate { RSliderChange(); });
        gSlider.onValueChanged.AddListener(delegate { GSliderChange(); });
        bSlider.onValueChanged.AddListener(delegate { BSliderChange(); });
        brushSizeSlider.onValueChanged.AddListener(delegate { BrushSizeSliderChange(); });
    }

    public void BrushSizeSliderChange()
    {
        int newBrushSize = ConvertSliderValueToBrushSize(brushSizeSlider.value) + 1;
        labelBrushSize.text = SIZE_LABEL_TEXT + newBrushSize.ToString();
        brush.SetBrushSize(newBrushSize);
    }

    public void RSliderChange()
    {     
        rInput.text = ConvertSliderValueToColor(rSlider.value).ToString();
        CreateColorFromSliders();
    }

    public void GSliderChange()
    {
        gInput.text = ConvertSliderValueToColor(gSlider.value).ToString();
        CreateColorFromSliders();
    }

    public void BSliderChange()
    {
        bInput.text = ConvertSliderValueToColor(bSlider.value).ToString();
        CreateColorFromSliders();
    }

    private void CreateColorFromSliders()
    {
        Color newColor = new Color(rSlider.value, gSlider.value, bSlider.value, 1);
        selectedColorImage.color = newColor;
        brush.SetBrushColor(newColor);
    }

    public void SetBrushCustomColor(Color color)
    {
        float rValue = ConvertSliderValueToColor(color.r);
        float gValue = ConvertSliderValueToColor(color.g);
        float bValue = ConvertSliderValueToColor(color.b);

        brush.SetBrushColor(color);
        selectedColorImage.color = color;
        rInput.text = rValue.ToString();
        gInput.text = gValue.ToString();
        bInput.text = bValue.ToString();
        rSlider.value = color.r;
        gSlider.value = color.g;
        bSlider.value = color.b;
    }

    public void SetColorFromButton(ButtonColor button)
    {
        SetBrushCustomColor(button.GetColor());
    }

    private float ConvertColorToSliderValue(float colorValue)
    {
        return colorValue / RGB_MAX_VALUE;
    }

    private int ConvertSliderValueToColor(float sliderValue)
    {
        return (int)(sliderValue * RGB_MAX_VALUE);
    }

    private int ConvertSliderValueToBrushSize(float sliderValue)
    {
        return (int)(sliderValue * (SIZE_MAX_VALUE-1));
    }
}
