using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Brush : Tool
{        
    private Color brushColor = Color.red;
    private int brushSize = 1;
    private Tile selectedTile;
 

    private List<Vector2> adjacentPositions = new List<Vector2>();
    private List<float> xPositions = new List<float>();
    private List<float> yPositions = new List<float>();
  
    public void SetBrushColor(Color color)
    {
        brushColor = color;
    }

    public void SetBrushSize(int size)
    {
        brushSize = size;
    }

    private void Update()
    {
        if (Input.GetMouseButton(0))
        {
            Paint();
        }
    }

    public void SetSelectedTile(Tile tile)
    {
        selectedTile = tile;
        CalculateAdjacentTiles();
        gameController.GameBrush.OnMouseEnterAdjacentTilesColor();
    }

    public void UnPaintSelectedTile()
    {
        OnMouseExitAdjacentTilesColor();       
        selectedTile = null;
    }

    private void CalculateAdjacentTiles()
    {
        adjacentPositions.Clear();
        xPositions.Clear();
        yPositions.Clear();

        //La manera de calcular los puntos adyacentes de el tile actual segun la brocha para numeros pares es b.size/2 hacia la izquierda y arriba, y (b.size/2) - 1 a derecha y abajo
        //La manera de calcular los puntos adyacentes de el tile actual segun la brocha para numeros impares es (b.size-1)/2 hacia cualquier lado


        int leftAndUpTiles = 0;
        int rightAndDownTiles = 0;

        xPositions.Add(selectedTile.Position.x);
        yPositions.Add(selectedTile.Position.y);

        if (brushSize % 2 == 0)
        {
            leftAndUpTiles = brushSize / 2;
            rightAndDownTiles = (brushSize / 2) - 1;
        }
        else
        {
            leftAndUpTiles = (brushSize - 1) / 2;
            rightAndDownTiles = leftAndUpTiles;
        }


        //Salva todas las posiciones de X y Y hacia arriba y a la izquierda de la posicion actual
        for (int i = leftAndUpTiles; i > 0; i--)
        {
            float leftXposition = selectedTile.Position.x - i;
            if (leftXposition >= 0)
            {
                xPositions.Add(leftXposition);
            }

            float upYPosition = selectedTile.Position.y + i;
            if (upYPosition < gameController.GetCanvasHeight())
            {
                yPositions.Add(upYPosition);
            }
        }

        //Salva todas las posiciones de X y Y hacia abajo y a la derecha de la posicion actual
        for (int j = rightAndDownTiles; j > 0; j--)
        {
            float rightXposition = selectedTile.Position.x + j;
            if (rightXposition < gameController.GetCanvasWidth())
            {
                xPositions.Add(rightXposition);
            }

            float downYPosition = selectedTile.Position.y - j;
            if (downYPosition >= 0)
            {
                yPositions.Add(downYPosition);
            }
        }

        //Genera todos las posiciones donde la brocha debe pintar y las guarda
        for (int k = 0; k < xPositions.Count; k++)
        {
            for (int l = 0; l < yPositions.Count; l++)
            {
                adjacentPositions.Add(new Vector2(xPositions[k], yPositions[l]));
            }
        }       
    }

    public void OnMouseEnterAdjacentTilesColor()
    {
        for (int i = 0; i < adjacentPositions.Count; i++)
        {
            gameController.GetTileInPosition(adjacentPositions[i]).SetOnMouseEnterColor(brushColor);
        }
    }

    public void OnMouseExitAdjacentTilesColor()
    {
        for (int i = 0; i < adjacentPositions.Count; i++)
        {
            gameController.GetTileInPosition(adjacentPositions[i]).SetOnMouseExitColor();
        }
    }

    public void Paint()
    {
        if (selectedTile != null)
        {
            selectedTile.SetTileColor(brushColor);
            for (int i = 0; i < adjacentPositions.Count; i++)
            {
                gameController.GetTileInPosition(adjacentPositions[i]).SetTileColor(brushColor);
            }
        }
    }

    public override void SetActiveTool(bool status)
    {
        if (status)
            gameController.UiBrushPanel.gameObject.SetActive(true);
        else
            gameController.UiBrushPanel.gameObject.SetActive(false);

        base.SetActiveTool(status);
    }
}
