using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ButtonColor : MonoBehaviour
{

    [SerializeField] private Color buttonColor;

    // Start is called before the first frame update
    void Start()
    {
        GetComponent<Image>().color = buttonColor;
    }

    public Color GetColor()
    {
        return buttonColor;
    }
    
}
